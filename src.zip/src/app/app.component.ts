import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { NgbModal, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    NgbModalModule
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  loginUsername = '';
  loginPassword = '';
  signupUsername = '';
  signupPassword = '';

  constructor(public auth: AuthService, private modalService: NgbModal) {}

  openLoginModal(content: any) {
    this.modalService.open(content);
  }

  openSignupModal(content: any) {
    this.modalService.open(content);
  }

  confirmLogin() {
    this.auth.login(this.loginUsername);  // Mock logic
    this.loginUsername = '';
    this.loginPassword = '';
  }

  confirmSignup() {
    this.auth.login(this.signupUsername);  // Simulated signup -> login
    this.signupUsername = '';
    this.signupPassword = '';
  }

  logout() {
    this.auth.logout();
  }
}
